import{d as p}from"./useFeatureAccess-DdfHzZ9p.js";import{j as e}from"./browser-polyfill-DGrheA3Q.js";function f({feature:n,children:o}){return p(n).enabled?o:null}function y({inventory:n,onBack:o,onRemoveItem:r,onClearInventory:s}){const l=t=>{if(typeof t.data?.snapshot=="string")return`<img src="${t.data.snapshot}" style="max-width: 90px; max-height: 50px; object-fit: contain;" />`;if(t.data?.snapshot&&typeof t.data.snapshot=="object"){const i=t.data.snapshot;if(i.metadata?.hasImage&&i.metadata?.imageUrl)return`
          <img src="${i.metadata.imageUrl}" 
               style="max-width: 90px; max-height: 50px; object-fit: contain;" 
               onerror="this.style.display='none'; this.nextElementSibling.style.display='block';" />
          <div style="display: none; font-size: 10px; color: #6b7280; text-align: center;">
            ${i.metadata.tagName}
          </div>
        `;const d=i.metadata?.textContent?.slice(0,30)||i.metadata?.tagName||"element",c=i.styles?.backgroundColor||"#f9fafb",x=i.styles?.color||"#1f2937";return`
        <div style="
          width: 90px; 
          height: 50px; 
          background: ${c};
          color: ${x};
          font-size: 9px;
          padding: 4px;
          display: flex;
          align-items: center;
          justify-content: center;
          text-align: center;
          overflow: hidden;
          word-break: break-word;
        ">
          ${d}
        </div>
      `}return`
      <div style="
        width: 90px; 
        height: 50px; 
        background: #f9fafb;
        color: #6b7280;
        font-size: 9px;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
      ">
        ${t.type}
      </div>
    `},a=t=>{switch(t){case"element":return"#6366f1";case"site_signature":return"#10b981";case"interaction":return"#f59e0b";default:return"#6b7280"}};return e.jsxs("div",{style:{padding:"16px",height:"100%",display:"flex",flexDirection:"column"},children:[e.jsxs("header",{style:{marginBottom:"16px"},children:[e.jsx("button",{onClick:o,style:{display:"block",background:"none",border:"none",fontSize:"12px",color:"#6b7280",cursor:"pointer",padding:0,marginBottom:"8px"},children:"\u2190 back"}),e.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between"},children:[e.jsxs("h1",{style:{margin:0,fontSize:"18px",color:"#1f2937"},children:["Inventory (",n.totalItems,")"]}),n.items.length>0&&e.jsx("button",{onClick:s,style:{background:"#ef4444",color:"white",border:"none",borderRadius:"4px",fontSize:"10px",padding:"4px 6px",cursor:"pointer"},title:"Clear all items",children:"Clear All"})]})]}),e.jsx("main",{style:{flex:1,overflow:"auto"},children:n.items.length===0?e.jsxs("div",{style:{textAlign:"center",padding:"40px 20px",color:"#6b7280",fontSize:"14px"},children:[e.jsx("div",{style:{marginBottom:"8px"},children:"Your bag is empty"}),e.jsx("div",{children:"Start exploring to collect items!"})]}):e.jsx("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"8px"},children:n.items.map(t=>e.jsxs("div",{style:{background:"#f9fafb",border:"1px solid #e5e7eb",borderRadius:"8px",padding:"8px",fontSize:"11px",display:"flex",flexDirection:"column",alignItems:"center",textAlign:"center",minHeight:"140px"},children:[e.jsx("div",{style:{marginBottom:"8px",display:"flex",alignItems:"center",justifyContent:"center",width:"100%",height:"60px"},children:t.type==="site_signature"?e.jsx("img",{src:t.data?.favicon||`${new URL(t.sourceUrl).origin}/favicon.ico`,alt:"Site favicon",style:{width:"32px",height:"32px",borderRadius:"4px",objectFit:"cover"},onError:i=>{i.target.src=`data:image/svg+xml;base64,${btoa(`
                          <svg width="32" height="32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
                            <rect width="32" height="32" fill="#4a9a8a" rx="4"/>
                            <circle cx="16" cy="16" r="8" fill="none" stroke="white" stroke-width="1.5"/>
                            <ellipse cx="16" cy="16" rx="4" ry="8" fill="none" stroke="white" stroke-width="1.5"/>
                            <line x1="8" y1="16" x2="24" y2="16" stroke="white" stroke-width="1.5"/>
                          </svg>
                        `)}`}}):e.jsx("div",{style:{maxWidth:"100px",maxHeight:"60px",borderRadius:"4px",border:"1px solid #e5e7eb",display:"flex",alignItems:"center",justifyContent:"center"},dangerouslySetInnerHTML:{__html:l(t)}})}),e.jsxs("div",{style:{flex:1,display:"flex",flexDirection:"column",justifyContent:"space-between",width:"100%"},children:[e.jsxs("div",{children:[e.jsx("div",{style:{fontWeight:"bold",fontSize:"12px",color:"#1f2937",marginBottom:"2px",lineHeight:"1.2"},children:t.name.length>25?t.name.slice(0,25)+"...":t.name}),e.jsx("div",{style:{color:"#6b7280",fontSize:"10px",marginBottom:"6px",lineHeight:"1.2"},children:t.description.length>40?t.description.slice(0,40)+"...":t.description})]}),e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginTop:"4px"},children:[e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"4px"},children:[e.jsx("span",{style:{background:a(t.type),color:"white",padding:"1px 4px",borderRadius:"3px",fontSize:"9px",fontWeight:"500"},children:t.type==="site_signature"?"site":"item"}),e.jsx("button",{onClick:i=>{i.stopPropagation(),r(t.id)},style:{background:"#ef4444",color:"white",border:"none",borderRadius:"2px",fontSize:"8px",padding:"1px 3px",cursor:"pointer",lineHeight:"1"},title:"Remove item",children:"\xD7"})]}),e.jsx("span",{style:{color:"#9ca3af",fontSize:"9px"},children:new Date(t.collectedAt).toLocaleDateString()})]})]})]},t.id))})}),e.jsx("footer",{style:{marginTop:"16px",paddingTop:"16px",borderTop:"1px solid #e5e7eb",fontSize:"10px",color:"#9ca3af",textAlign:"center"},children:n.items.length>0&&`Last updated ${new Date(n.lastUpdated).toLocaleDateString()}`})]})}export{f as F,y as I};
