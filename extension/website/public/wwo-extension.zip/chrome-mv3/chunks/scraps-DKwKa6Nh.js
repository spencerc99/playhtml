import{r as s,j as o,R as st,c as it,b as lt}from"./browser-polyfill-DGrheA3Q.js";import{E as ct}from"./ExtensionPageNav-XGScJ5oC.js";import{r as dt}from"./index-1jXPDq7q.js";import{h as me,s as R}from"./styleUtils-CpvIGndW.js";import"./useFeatureAccess-DdfHzZ9p.js";const pt=.55,Ee=420,We=2,ut=3,ht='a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';function He(e,t){return`${Math.round(e)} x ${Math.round(t)}`}function gt(e){switch(e.kind){case"image":{const t=[{label:"dimensions",value:He(e.naturalWidth,e.naturalHeight)}],n=e.alt?.trim();return n&&t.push({label:"alt text",value:n}),t}case"button":{const t=e.text.trim();return t?[{label:"label",value:t}]:[]}case"svg-icon":return[{label:"dimensions",value:He(e.width,e.height)}];case"cursor":{const t=[];return e.hotspotX!==void 0&&e.hotspotY!==void 0&&t.push({label:"hotspot",value:`${Math.round(e.hotspotX)}, ${Math.round(e.hotspotY)}`}),t}}}function ft(e){const t=new Intl.DateTimeFormat("en-US",{month:"short",day:"numeric",year:"numeric"}).format(e),n=new Intl.DateTimeFormat("en-US",{hour:"numeric",minute:"2-digit"}).format(e);return`${t} \xB7 ${n}`}function xt(e,t){const n=Math.min(t.width,t.height)*pt;if(e.width<=0||e.height<=0)return{width:n,height:n};const r=e.width/e.height;return r>=1?{width:n,height:n/r}:{width:n*r,height:n}}function mt(e){const t=Math.max(-We,Math.min(We,e));return Math.round(t*100)/100}function _t(e,t,n){const r=t.width>0?e.width/t.width:1,l=t.height>0?e.height/t.height:1,h=e.left+e.width/2-n.x,p=e.top+e.height/2-n.y;return`translate(${Math.round(h)}px, ${Math.round(p)}px) scale(${r.toFixed(4)}, ${l.toFixed(4)}) rotate(${e.rotation}deg)`}const bt=`
  .scrap-lightbox {
    position: fixed;
    inset: 0;
    z-index: 1000;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 32px;
    background: rgba(250, 247, 242, 0.88);
    backdrop-filter: blur(6px);
    opacity: 0;
    transition: opacity 240ms ease;
  }

  .scrap-lightbox--visible {
    opacity: 1;
  }

  .scrap-lightbox::before {
    position: absolute;
    inset: 0 0 auto;
    z-index: 1;
    height: 68px;
    border-bottom: 1px solid rgba(61, 56, 51, 0.08);
    background: #faf7f2;
    content: "";
  }

  .scrap-lightbox__layout {
    position: relative;
    z-index: 2;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 40px;
    width: 100%;
    max-width: 1180px;
    max-height: 100%;
  }

  .scrap-lightbox__stage {
    position: relative;
    display: flex;
    flex: 0 1 auto;
    align-items: center;
    justify-content: center;
  }

  .scrap-lightbox__scrap {
    position: relative;
    display: block;
    transform-origin: center;
    filter: drop-shadow(0 26px 40px rgba(61, 56, 51, 0.28));
    transition:
      transform ${Ee}ms cubic-bezier(0.22, 1, 0.36, 1),
      filter ${Ee}ms ease;
  }

  .scrap-lightbox__scrap-media {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
  }

  .scrap-lightbox__scrap-media > svg,
  .scrap-lightbox__scrap-media > img {
    width: 100%;
    height: 100%;
    display: block;
    object-fit: contain;
  }

  .scrap-lightbox__panel {
    box-sizing: border-box;
    flex: 0 0 300px;
    max-width: 300px;
    max-height: 100%;
    overflow-y: auto;
    padding: 20px;
    border: 1px solid rgba(61, 56, 51, 0.2);
    border-radius: 4px;
    background: #f5f0e8;
    box-shadow: 0 14px 34px rgba(61, 56, 51, 0.16);
    color: #3d3833;
    font-family: "Atkinson Hyperlegible", system-ui, sans-serif;
    font-size: 13px;
    line-height: 1.55;
  }

  .scrap-lightbox__chip {
    display: inline-block;
    padding: 3px 8px;
    border: 1px solid rgba(74, 154, 138, 0.5);
    border-radius: 999px;
    background: rgba(74, 154, 138, 0.1);
    color: #4a9a8a;
    font-family: "Martian Mono", monospace;
    font-size: 9px;
    letter-spacing: 0.08em;
    text-transform: uppercase;
  }

  .scrap-lightbox__heading {
    margin: 14px 0 0;
    font-family: Lora, Georgia, serif;
    font-size: 17px;
    font-weight: 600;
    line-height: 1.3;
  }

  .scrap-lightbox__source {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-top: 10px;
  }

  .scrap-lightbox__favicon {
    width: 18px;
    height: 18px;
    flex: 0 0 18px;
    border-radius: 3px;
    object-fit: cover;
  }

  .scrap-lightbox__domain {
    overflow: hidden;
    color: #3d3833;
    font-family: "Martian Mono", monospace;
    font-size: 10px;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .scrap-lightbox__rows {
    margin: 16px 0 0;
    padding-top: 14px;
    border-top: 1px solid rgba(61, 56, 51, 0.14);
  }

  .scrap-lightbox__row {
    display: flex;
    gap: 10px;
    margin-top: 8px;
  }

  .scrap-lightbox__row:first-child {
    margin-top: 0;
  }

  .scrap-lightbox__row-label {
    flex: 0 0 84px;
    color: #8a8279;
    font-family: "Martian Mono", monospace;
    font-size: 9px;
    letter-spacing: 0.04em;
    text-transform: uppercase;
  }

  .scrap-lightbox__row-value {
    flex: 1 1 auto;
    min-width: 0;
    color: #3d3833;
    font-family: "Martian Mono", monospace;
    font-size: 10px;
    overflow-wrap: anywhere;
  }

  .scrap-lightbox__row-value a {
    color: #5b8db8;
  }

  /* A long URL stays on one line and truncates; the link still carries it whole. */
  .scrap-lightbox__row-value--url a {
    display: block;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .scrap-lightbox__actions {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 8px;
    margin-top: 18px;
    padding-top: 14px;
    border-top: 1px solid rgba(61, 56, 51, 0.14);
  }

  .scrap-lightbox__action {
    display: inline-flex;
    align-items: center;
    padding: 7px 14px;
    border: 1px solid #4a9a8a;
    border-radius: 3px;
    background: #4a9a8a;
    color: #faf7f2;
    font-family: "Martian Mono", monospace;
    font-size: 10px;
    text-decoration: none;
    transition: background-color 140ms ease, box-shadow 140ms ease;
  }

  .scrap-lightbox__action:hover,
  .scrap-lightbox__action:focus-visible {
    background: #3d8375;
    box-shadow: 0 5px 12px rgba(61, 56, 51, 0.18);
  }

  .scrap-lightbox__close {
    position: absolute;
    top: 16px;
    right: 20px;
    width: 34px;
    height: 34px;
    padding: 0;
    border: 1px solid rgba(61, 56, 51, 0.2);
    border-radius: 50%;
    z-index: 3;
    background: #faf7f2;
    box-shadow: 0 3px 10px rgba(61, 56, 51, 0.12);
    color: #3d3833;
    cursor: pointer;
    font-family: "Atkinson Hyperlegible", system-ui, sans-serif;
    font-size: 17px;
    line-height: 1;
  }

  .scrap-lightbox__close:hover,
  .scrap-lightbox__close:focus-visible {
    border-color: #c4724e;
    color: #c4724e;
  }

  .scrap-lightbox__step {
    position: absolute;
    z-index: 3;
    top: 50%;
    width: 34px;
    height: 34px;
    padding: 0;
    border: 1px solid rgba(61, 56, 51, 0.16);
    border-radius: 50%;
    background: rgba(245, 240, 232, 0.9);
    color: #3d3833;
    cursor: pointer;
    font-family: "Atkinson Hyperlegible", system-ui, sans-serif;
    font-size: 15px;
    line-height: 1;
    transform: translateY(-50%);
  }

  .scrap-lightbox__step--previous {
    left: 14px;
  }

  .scrap-lightbox__step--next {
    right: 14px;
  }

  .scrap-lightbox__step:hover,
  .scrap-lightbox__step:focus-visible {
    border-color: #4a9a8a;
    color: #4a9a8a;
  }

  @media (max-width: 720px) {
    .scrap-lightbox__layout {
      flex-direction: column;
      gap: 20px;
      overflow-y: auto;
    }

    .scrap-lightbox__panel {
      flex: 1 1 auto;
      width: 100%;
      max-width: none;
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .scrap-lightbox__scrap {
      transition: none;
    }
  }
`;function wt({item:e}){switch(e.kind){case"image":return o.jsx("div",{className:"scrap-lightbox__scrap-media",children:o.jsx("img",{src:e.src,alt:e.alt??"",draggable:!1})});case"button":return o.jsx("div",{className:"scrap-lightbox__scrap-media",style:{display:"flex",alignItems:"center",justifyContent:"center"},children:o.jsxs("span",{style:{...e.styles,display:"inline-flex",alignItems:"center",justifyContent:"center",whiteSpace:"nowrap",transform:`scale(${ut})`},children:[e.innerSvg&&o.jsx("span",{"aria-hidden":"true",style:{display:"inline-flex",width:"1em",height:"1em",marginRight:"0.45em"},dangerouslySetInnerHTML:{__html:e.innerSvg}}),e.text]})});case"svg-icon":return o.jsx("div",{className:"scrap-lightbox__scrap-media","aria-hidden":"true",dangerouslySetInnerHTML:{__html:e.markup}});case"cursor":return o.jsx("div",{className:"scrap-lightbox__scrap-media",children:o.jsx("img",{src:e.url,alt:"",draggable:!1,style:{imageRendering:"pixelated"}})})}}function yt({item:e,origin:t,faviconSrc:n,faviconAvailable:r,onFaviconError:l,placeholderColor:h,hasPrevious:p,hasNext:u,prefersReducedMotion:c,currentOrigin:x,onClose:y,onPrevious:A,onNext:v}){const z=s.useRef(null),O=s.useRef(null),M=s.useRef(null),[b,j]=s.useState(c),[S,Y]=s.useState({x:0,y:0}),[E,G]=s.useState(()=>({width:typeof window>"u"?1024:window.innerWidth,height:typeof window>"u"?768:window.innerHeight})),[W,B]=s.useState(t);s.useEffect(()=>B(t),[t]);const C=s.useMemo(()=>xt(t,E),[t,E]),Q=mt(t.rotation);s.useEffect(()=>{const g=()=>G({width:window.innerWidth,height:window.innerHeight});return window.addEventListener("resize",g),()=>window.removeEventListener("resize",g)},[]),s.useLayoutEffect(()=>{const g=M.current;if(!g)return;const m=g.getBoundingClientRect();Y({x:m.left+m.width/2,y:m.top+m.height/2})},[e.key,C.height,C.width]),s.useLayoutEffect(()=>{if(c)return;j(!1);const g=window.requestAnimationFrame(()=>j(!0));return()=>window.cancelAnimationFrame(g)},[e.key,c]),s.useEffect(()=>{O.current?.focus()},[]);const I=()=>{if(c){y();return}const g=x?.();g&&B(g),j(!1),window.setTimeout(y,Ee)},D=s.useRef(I);D.current=I,s.useEffect(()=>{const g=m=>{if(m.key==="Tab"){const K=z.current;if(!K)return;const U=Array.from(K.querySelectorAll(ht)).filter(V=>V.tabIndex!==-1);if(m.preventDefault(),U.length===0){O.current?.focus();return}const le=document.activeElement,F=U.findIndex(V=>V===le),te=m.shiftKey?-1:1,X=F===-1?m.shiftKey?U.length-1:0:(F+te+U.length)%U.length;U[X].focus();return}if(m.key==="Escape"){m.preventDefault(),D.current();return}if(m.key==="ArrowLeft"&&p){m.preventDefault(),A();return}m.key==="ArrowRight"&&u&&(m.preventDefault(),v())};return window.addEventListener("keydown",g,!0),()=>window.removeEventListener("keydown",g,!0)},[u,p,v,A]),s.useEffect(()=>{const g=document.body,m=g.style.overflow;return g.style.overflow="hidden",()=>{g.style.overflow=m}},[]);const L={width:C.width,height:C.height,transform:b?`rotate(${Q}deg)`:_t(W,C,S)};b||(L.filter="drop-shadow(0 4px 6px rgba(61, 56, 51, 0.16))");const H=e.pageTitle.trim(),ee=[{label:"collected",value:ft(e.ts)},...gt(e)];return o.jsxs("div",{ref:z,className:`scrap-lightbox${b?" scrap-lightbox--visible":""}`,onClick:g=>{g.target===g.currentTarget&&I()},children:[o.jsx("style",{children:bt}),o.jsxs("div",{ref:O,role:"dialog","aria-modal":"true","aria-label":`Examine ${e.kind} from ${e.domain}`,tabIndex:-1,className:"scrap-lightbox__layout",style:{outline:"none"},children:[o.jsx("div",{ref:M,className:"scrap-lightbox__stage",children:o.jsx("div",{className:"scrap-lightbox__scrap",style:L,children:o.jsx(wt,{item:e})})}),o.jsxs("aside",{className:"scrap-lightbox__panel",children:[o.jsx("span",{className:"scrap-lightbox__chip",children:e.kind}),H&&o.jsx("h2",{className:"scrap-lightbox__heading",children:H}),o.jsxs("div",{className:"scrap-lightbox__source",children:[r?o.jsx("img",{className:"scrap-lightbox__favicon",src:n,alt:"",onError:l}):o.jsx("span",{className:"scrap-lightbox__favicon",style:{backgroundColor:h}}),o.jsx("span",{className:"scrap-lightbox__domain",children:e.domain})]}),o.jsxs("div",{className:"scrap-lightbox__rows",children:[ee.map(g=>o.jsxs("div",{className:"scrap-lightbox__row",children:[o.jsx("span",{className:"scrap-lightbox__row-label",children:g.label}),o.jsx("span",{className:"scrap-lightbox__row-value",children:g.value})]},g.label)),e.pageUrl&&o.jsxs("div",{className:"scrap-lightbox__row",children:[o.jsx("span",{className:"scrap-lightbox__row-label",children:"found at"}),o.jsx("span",{className:"scrap-lightbox__row-value scrap-lightbox__row-value--url",children:o.jsx("a",{href:e.pageUrl,target:"_blank",rel:"noopener noreferrer",title:e.pageUrl,children:e.pageUrl})})]})]}),e.pageUrl&&o.jsx("div",{className:"scrap-lightbox__actions",children:o.jsx("a",{className:"scrap-lightbox__action",href:e.pageUrl,target:"_blank",rel:"noopener noreferrer",children:"visit page \u2192"})})]})]}),p&&o.jsx("button",{type:"button",className:"scrap-lightbox__step scrap-lightbox__step--previous","aria-label":"Previous scrap",onClick:A,children:"\u2190"}),u&&o.jsx("button",{type:"button",className:"scrap-lightbox__step scrap-lightbox__step--next","aria-label":"Next scrap",onClick:v,children:"\u2192"}),o.jsx("button",{type:"button",className:"scrap-lightbox__close","aria-label":"Close examine view",onClick:I,children:"\xD7"})]})}function Ke(e){let t=0;for(let n=0;n<e.length;n++){const r=e.charCodeAt(n);t=(t<<5)-t+r,t=t&t}return Math.abs(t)}const vt=/\bd="([^"]*)"/g,kt=/\bviewBox="([^"]*)"/,St=/\b(?:width|height|fill|stroke|style)="[^"]*"/g;function je(e){return e.trim().replace(/\s+/g," ")}function Mt(e){const t=[];for(const l of e.matchAll(vt))t.push(l[1]);const n=e.match(kt)?.[1]??"";if(t.length>0)return String(Ke(je(t.join("|")+"|"+n)));const r=e.replace(St,"");return String(Ke(je(r)))}function Et(e){try{const t=new URL(e);return t.search="",t.hash="",t.toString()}catch{return e}}function jt(e,t,n){const r=je(t.toLowerCase());return`${e}|button|${r}|${n??""}`}function Tt(e,t){return`${e}|svg|${Mt(t)}`}const At=4,Ve=200,Ct=5600,It=100,Nt=500,Rt=160,ie=112,zt=.25,Ot=3,ue=1400,Te=1e3,qe=7e3,Dt=1/6,Pe=2,Lt=4,Ut=100,Bt=300,Ft=.15,$t=.05,Wt=[96,152,208],he=48,Ht=[{kind:"image",label:"images"},{kind:"button",label:"buttons"},{kind:"svg-icon",label:"icons"},{kind:"cursor",label:"cursors"}];function Kt(e,t){return e<=0||t<=0?Ve:xe(It,Nt,Math.round(e*t/Ct))}function ge(e){switch(e.kind){case"image":return e.naturalWidth*e.naturalHeight;case"button":return Ze(e.text)*40;case"svg-icon":return e.width*e.height;case"cursor":return he*he}}function fe(e,t){return R(t+me(e.key))}function Pt(e){switch(e.kind){case"image":return Et(e.src);case"button":return jt(e.domain,e.text,e.styles.backgroundColor);case"svg-icon":return Tt(e.domain,e.markup);case"cursor":return e.url}}function Yt(e,t,n){const r=ge(t)-ge(e);if(r!==0)return r;const l=t.ts-e.ts;if(l!==0)return l;const h=fe(e,n)-fe(t,n);return h!==0?h:e.key.localeCompare(t.key)}function Ae(e){const t=new Map;for(const r of e){const l=Pt(r),h=t.get(l);(!h||r.ts>h.ts)&&t.set(l,r)}const n=new Map;for(const r of t.values()){const l=n.get(r.key);(!l||r.ts>l.ts)&&n.set(r.key,r)}return Array.from(n.values())}function Gt(e,t){const n=Math.max(0,Math.floor(t.perDomainCap??At)),r=Math.max(0,Math.floor(t.targetCount??Ve));if(n===0||r===0)return[];const l=new Map;for(const u of Ae(e)){const c=l.get(u.domain);c?c.push(u):l.set(u.domain,[u])}const h=Array.from(l.entries()).map(([u,c])=>({domain:u,scraps:c.slice().sort((x,y)=>Yt(x,y,t.seed)).slice(0,n)})).sort((u,c)=>{const x=fe(u.scraps[0],t.seed)-fe(c.scraps[0],t.seed);return x!==0?x:u.domain.localeCompare(c.domain)}),p=[];for(let u=0;p.length<r;u+=1){let c=!1;for(const x of h){const y=x.scraps[u];if(y&&(p.push(y),c=!0,p.length===r))break}if(!c)break}return p}function Xt(e){return e.ashore.reduce((t,n)=>n===null?t:t+1,0)}function Se(e,t,n){return t+e()*(n-t)}function Vt(e,t,n){const r=Xt(e),l=Math.max(0,Math.floor(t*(1-Ft))),h=Math.max(1,Math.round(t*(1+$t))),p=e.offshore.length>0&&r<h,u=r>0,x=(r<l?!0:r>=t?!1:n()<.5)&&p?"in":u?"out":"in",y=Math.round(Se(n,Te,qe));return x==="out"&&r>Pe&&n()<Dt?{kind:"wave",count:Math.min(r,Math.floor(Se(n,Pe,Lt+1))),delayMs:y,staggerMs:Math.round(Se(n,Ut,Bt))}:{kind:x,count:1,delayMs:y,staggerMs:0}}function qt(e,t,n){const r=new Set(e),l=new Set,h=[];if(n)for(const u of[...n.ashore,...n.offshore])u===null||!r.has(u)||l.has(u)||(l.add(u),h.push(u));for(const u of e)l.has(u)||(l.add(u),h.push(u));const p=Math.min(Math.max(0,t),h.length);return{ashore:h.slice(0,p),offshore:h.slice(p)}}function Zt(e,t){if(t<0||t>=e.ashore.length)return e;const n=e.ashore[t];if(n===null)return e;const r=e.ashore.slice();return r[t]=null,{ashore:r,offshore:[...e.offshore,n]}}function Jt(e,t){if(e.offshore.length===0)return e;const[n,...r]=e.offshore,l=e.ashore.slice(),h=l.indexOf(null);return h===-1?l.push(n):l[h]=n,{ashore:l,offshore:r}}function Qt(e){const t=[];return e.ashore.forEach((n,r)=>{n!==null&&t.push(r)}),t}function Ce(e){return`hsl(${me(e)%360}, 30%, 72%)`}function ea(e){return new Intl.DateTimeFormat("en-US",{month:"short",day:"numeric",year:"numeric"}).format(e)}function xe(e,t,n){return Math.max(e,Math.min(t,n))}function Ze(e){return xe(100,240,48+e.trim().length*8)}function ta(e,t,n){const r=Wt[t]*(.92+R(n,1)*.16),l=Math.max(e.naturalWidth,e.naturalHeight);return l<=0?{width:0,height:0}:{width:r*(e.naturalWidth/l),height:r*(e.naturalHeight/l)}}function aa(e,t){if(e.width<=0||e.height<=0)return{width:0,height:0};const n=56+R(t,1)*40,r=e.width/e.height;return r>=1?{width:n,height:n/xe(1,2,r)}:{width:n*xe(.5,1,r),height:n}}function Je(e,t,n){switch(e.kind){case"image":return ta(e,t,n);case"button":return{width:Ze(e.text),height:40};case"svg-icon":return aa(e,n);case"cursor":return{width:he,height:he}}}function Ie(e){const t=e.filter(n=>n.kind==="image").map(ge).sort((n,r)=>n-r);return{lowerArea:t[Math.floor((t.length-1)/3)],upperArea:t[Math.floor((t.length-1)*2/3)]}}function Qe(e,t,n){const r=ge(e);return e.kind!=="image"||r<=t?0:r<=n?1:2}function oa(e,t,n,r,l,h=Ie(e)){if(e.length===0||t<=0||r<=0)return{fieldHeight:0,layout:[]};const p=Math.max(1,Math.floor(t/Rt)),u=Math.ceil(e.length/p),c=Math.max(r,u*ie),x=t/p,y=r*zt,A=Math.max(0,Math.floor((n-y)/ie)),v=Math.min(u-1,Math.ceil((n+r+y)/ie)),z=A*p,O=Math.min(e.length,(v+1)*p),M=[];for(let b=z;b<O;b+=1){const j=e[b],S=l+me(j.key),Y=Qe(j,h.lowerArea,h.upperArea),E=Je(j,Y,S),G=b%p,W=Math.floor(b/p),B=(R(S,2)-.5)*x*.45,C=(R(S,3)-.5)*ie*.35,Q=(G+.5)*x+B-E.width/2,I=(W+.5)*ie+C-E.height/2,D=Math.max(4,Math.min(t-E.width-4,Q)),L=Math.max(4,Math.min(c-E.height-4,I));M.push({item:j,slotIndex:b,x:D,y:L,width:E.width,height:E.height,rotation:R(S,4)*12-6,zIndex:Math.floor(R(S,5)*Ot)+1,cardAbove:L-n>r*.58,cardRightAligned:D>t*.68})}return{fieldHeight:c,layout:M}}function na(e,t,n,r){if(e.length===0||t===0||n===0)return[];const l=e.filter(v=>v!==null);if(l.length===0)return[];const{lowerArea:h,upperArea:p}=Ie(l),u=t/n,c=Math.max(1,Math.ceil(Math.sqrt(e.length*u))),x=Math.ceil(e.length/c),y=t/c,A=n/x;return e.flatMap((v,z)=>{if(v===null)return[];const O=Qe(v,h,p),M=r+me(v.key),b=Je(v,O,M),j=z%c,S=Math.floor(z/c),Y=(R(M,2)-.5)*y*.6,E=(R(M,3)-.5)*A*.6,G=(j+.5)*y+Y-b.width/2,W=(S+.5)*A+E-b.height/2,B=Math.max(4,Math.min(t-b.width-4,G)),C=Math.max(4,Math.min(n-b.height-4,W));return[{item:v,slotIndex:z,x:B,y:C,width:b.width,height:b.height,rotation:R(M,4)*12-6,zIndex:Math.floor(R(M,5)*80)+1,cardAbove:C>n*.58,cardRightAligned:B>t*.68}]})}const ra=`
  .scrap-collage__controls {
    position: absolute;
    bottom: 12px;
    left: 50%;
    z-index: 300;
    display: flex;
    flex-direction: column;
    align-items: stretch;
    gap: 7px;
    box-sizing: border-box;
    max-width: calc(100% - 24px);
    padding: 7px;
    border: 1px solid rgba(61, 56, 51, 0.2);
    border-radius: 5px;
    background: #f5f0e8;
    box-shadow: 0 8px 24px rgba(61, 56, 51, 0.2);
    pointer-events: auto;
    transform: translateX(-50%);
  }

  .scrap-collage__controls--collapsed {
    padding: 0;
    border: 0;
    background: transparent;
    box-shadow: none;
  }

  .scrap-collage__control-group {
    display: flex;
    align-items: center;
    gap: 5px;
  }

  .scrap-collage__controls-header,
  .scrap-collage__controls-body {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
  }

  .scrap-collage__controls-header {
    justify-content: space-between;
    padding-bottom: 6px;
    border-bottom: 1px solid rgba(61, 56, 51, 0.12);
  }

  .scrap-collage__view-switch {
    display: inline-flex;
    padding: 2px;
    border: 1px solid rgba(61, 56, 51, 0.18);
    border-radius: 999px;
    background: rgba(61, 56, 51, 0.05);
  }

  .scrap-collage__view-option {
    appearance: none;
    padding: 3px 12px;
    border: 0;
    border-radius: 999px;
    background: transparent;
    color: #827a72;
    cursor: pointer;
    font-family: "Martian Mono", monospace;
    font-size: 9px;
    line-height: 1.4;
  }

  .scrap-collage__view-option[aria-pressed="true"] {
    background: #faf9f6;
    box-shadow: 0 1px 4px rgba(61, 56, 51, 0.18);
    color: #3d3833;
  }

  .scrap-collage__view-option:focus-visible {
    outline: 2px solid rgba(74, 154, 138, 0.45);
    outline-offset: 1px;
  }

  .scrap-collage__archive-summary {
    color: #827a72;
    font-family: "Martian Mono", monospace;
    font-size: 8px;
    white-space: nowrap;
  }

  .scrap-collage__control-label {
    color: #827a72;
    font-family: "Martian Mono", monospace;
    font-size: 8px;
    letter-spacing: 0.03em;
  }

  .scrap-collage__select {
    appearance: none;
    min-width: 112px;
    padding: 4px 24px 4px 9px;
    border: 1px solid rgba(61, 56, 51, 0.18);
    border-radius: 3px;
    background-color: #faf9f6;
    background-image:
      linear-gradient(45deg, transparent 50%, #827a72 50%),
      linear-gradient(135deg, #827a72 50%, transparent 50%);
    background-position:
      calc(100% - 11px) 50%,
      calc(100% - 7px) 50%;
    background-repeat: no-repeat;
    background-size: 4px 4px, 4px 4px;
    color: #3d3833;
    cursor: pointer;
    font-family: "Martian Mono", monospace;
    font-size: 9px;
    line-height: 1.4;
  }

  .scrap-collage__filter {
    appearance: none;
    padding: 4px 10px;
    border: 1px solid rgba(61, 56, 51, 0.18);
    border-radius: 999px;
    background: #f5f0e8;
    color: #3d3833;
    cursor: pointer;
    font-family: "Martian Mono", monospace;
    font-size: 9px;
    line-height: 1.4;
    white-space: nowrap;
    transition:
      transform 140ms ease,
      box-shadow 140ms ease,
      border-color 140ms ease,
      background-color 140ms ease,
      color 140ms ease;
  }

  .scrap-collage__filter--collapse {
    min-width: 30px;
    padding-inline: 8px;
  }

  .scrap-collage__filter-count {
    color: #8a8279;
  }

  .scrap-collage__filter[aria-pressed="true"] {
    border-color: #4a9a8a;
    background: rgba(74, 154, 138, 0.1);
    color: #4a9a8a;
  }

  .scrap-collage__filter[aria-pressed="true"] .scrap-collage__filter-count {
    color: #4a9a8a;
  }

  .scrap-collage__filter:hover,
  .scrap-collage__filter:focus-visible {
    border-color: #4a9a8a;
    box-shadow: 0 5px 10px rgba(61, 56, 51, 0.14);
    transform: translateY(-2px);
  }

  .scrap-collage__select:focus-visible {
    border-color: #4a9a8a;
    outline: 2px solid rgba(74, 154, 138, 0.45);
    outline-offset: 2px;
  }

  .scrap-collage__filter:focus-visible {
    outline: 2px solid rgba(74, 154, 138, 0.45);
    outline-offset: 2px;
  }

  .scrap-collage__filter--cycle {
    gap: 6px;
  }

  .scrap-collage__cycle-status {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: #aaa59d;
    box-shadow: inset 0 0 0 1px rgba(61, 56, 51, 0.12);
    transition: background 140ms ease, box-shadow 140ms ease;
  }

  .scrap-collage__filter--cycle[aria-pressed="true"] {
    border-color: #4a9a70;
    background: rgba(74, 154, 112, 0.1);
    color: #3f855f;
  }

  .scrap-collage__filter--cycle[aria-pressed="true"] .scrap-collage__cycle-status {
    background: #4a9a70;
    box-shadow: 0 0 0 2px rgba(74, 154, 112, 0.16);
  }

  .scrap-collage__filter--cycle:hover,
  .scrap-collage__filter--cycle:focus-visible {
    border-color: #4a9a70;
  }

  .scrap-collage__filter--cycle:focus-visible {
    outline-color: rgba(74, 154, 112, 0.45);
  }

  .scrap-collage__scroll {
    position: absolute;
    inset: 0;
    overflow-y: auto;
    overflow-x: hidden;
    height: 100%;
  }

  @media (max-width: 620px) {
    .scrap-collage__controls:not(.scrap-collage__controls--collapsed) {
      width: calc(100% - 24px);
      align-items: stretch;
    }

    .scrap-collage__controls-body {
      flex-wrap: wrap;
    }

    .scrap-collage__controls-body .scrap-collage__control-group {
      flex: 1 1 auto;
    }

    .scrap-collage__select {
      flex: 1 1 auto;
      min-width: 0;
    }
  }

  .scrap-collage__field {
    position: relative;
    width: 100%;
  }

  .scrap-collage__tile {
    position: absolute;
    display: block;
    color: inherit;
    text-decoration: none;
    transform: rotate(var(--scrap-rotation));
    transform-origin: center;
    transition: transform 160ms ease, filter 160ms ease;
  }

  .scrap-collage__tile:hover,
  .scrap-collage__tile:focus-visible {
    z-index: 200 !important;
    transform: rotate(var(--scrap-rotation)) scale(1.06) translateY(-4px);
    filter: drop-shadow(0 12px 12px rgba(61, 56, 51, 0.2));
    outline: none;
  }

  .scrap-collage__image {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    display: block;
    object-fit: contain;
  }

  .scrap-collage__swatch {
    position: absolute;
    inset: 0;
    display: block;
    pointer-events: none;
    transition: opacity 420ms ease;
  }

  .scrap-collage__swatch--settled {
    opacity: 0;
  }

  .scrap-collage__developing {
    filter: blur(10px) saturate(0.35);
    opacity: 0;
    transition:
      filter 760ms ease,
      opacity 760ms ease;
  }

  .scrap-collage__developing.scrap-collage__developed {
    filter: blur(0) saturate(1);
    opacity: 1;
  }

  .scrap-collage__tile--washing-in {
    animation: scrap-collage-wash-in 900ms ease forwards;
  }

  .scrap-collage__tile--washing-out {
    animation: scrap-collage-wash-out ${ue}ms ease forwards;
    pointer-events: none;
  }

  @keyframes scrap-collage-wash-in {
    from {
      opacity: 0;
      transform: rotate(var(--scrap-rotation)) translateY(-18px);
    }
    to {
      opacity: 1;
      transform: rotate(var(--scrap-rotation)) translateY(0);
    }
  }

  @keyframes scrap-collage-wash-out {
    from {
      opacity: 1;
      transform: rotate(var(--scrap-rotation)) translateY(0);
    }
    to {
      opacity: 0;
      transform: rotate(var(--scrap-rotation)) translateY(30px);
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .scrap-collage__swatch,
    .scrap-collage__developing {
      transition: none;
    }

    .scrap-collage__developing {
      filter: none;
      opacity: 1;
    }

    .scrap-collage__tile--washing-in,
    .scrap-collage__tile--washing-out {
      animation: none;
    }
  }

  .scrap-collage__button {
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    pointer-events: none;
  }

  .scrap-collage__button-icon {
    display: inline-flex;
    width: 1em;
    height: 1em;
    flex: 0 0 auto;
    margin-right: 0.45em;
    pointer-events: none;
  }

  .scrap-collage__button-icon > svg {
    width: 100%;
    height: 100%;
    display: block;
  }

  .scrap-collage__svg {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    pointer-events: none;
  }

  .scrap-collage__svg > svg {
    max-width: 100%;
    max-height: 100%;
    display: block;
  }

  .scrap-collage__cursor {
    position: absolute;
    left: 50%;
    top: 50%;
    width: 32px;
    height: 32px;
    display: block;
    object-fit: contain;
    image-rendering: pixelated;
    pointer-events: none;
    transform: translate(-50%, -50%);
  }

  .scrap-collage__provenance {
    position: absolute;
    display: flex;
    align-items: flex-start;
    gap: 8px;
    width: max-content;
    max-width: 240px;
    padding: 9px 10px;
    border: 1px solid rgba(61, 56, 51, 0.18);
    border-radius: 3px;
    background: rgba(250, 249, 246, 0.96);
    box-shadow: 0 6px 18px rgba(61, 56, 51, 0.14);
    color: #3d3833;
    font-family: "Martian Mono", monospace;
    font-size: 9px;
    line-height: 1.45;
    opacity: 0;
    pointer-events: none;
    transform: translateY(3px);
    transition: opacity 120ms ease, transform 120ms ease;
  }

  .scrap-collage__tile:hover .scrap-collage__provenance,
  .scrap-collage__tile:focus-visible .scrap-collage__provenance {
    opacity: 1;
    transform: translateY(0);
  }

  .scrap-collage__favicon {
    width: 18px;
    height: 18px;
    flex: 0 0 18px;
    border-radius: 3px;
    object-fit: cover;
  }

  .scrap-collage__details {
    display: block;
    min-width: 0;
  }

  .scrap-collage__title {
    display: block;
    max-width: 196px;
    overflow: hidden;
    color: #3d3833;
    font-weight: 600;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .scrap-collage__metadata {
    display: block;
    margin-top: 2px;
    color: #827a72;
  }
`;function sa(e){if(e.pageTitle.trim())return e.pageTitle;switch(e.kind){case"image":return e.alt?.trim()||"image";case"button":return e.text.trim()||"button";case"svg-icon":return"icon";case"cursor":return"cursor"}}function Ye(e){switch(e.kind){case"image":return e.src.trim().length>0&&e.naturalWidth>0&&e.naturalHeight>0;case"button":return!!(e.text.trim()||e.innerSvg?.trim());case"svg-icon":return!!(e.markup.trim()&&e.width>0&&e.height>0);case"cursor":return e.url.trim().length>0}}function Ge({domain:e,loaded:t,style:n}){return o.jsx("span",{className:`scrap-collage__swatch${t?" scrap-collage__swatch--settled":""}`,"aria-hidden":"true",style:{backgroundColor:Ce(e),...n}})}function ia({item:e,loaded:t,onError:n,onLoad:r}){switch(e.kind){case"image":return o.jsxs(o.Fragment,{children:[o.jsx(Ge,{domain:e.domain,loaded:t}),o.jsx("img",{className:`scrap-collage__image scrap-collage__developing${t?" scrap-collage__developed":""}`,src:e.src,alt:e.alt??"",loading:"lazy",draggable:!1,onLoad:r,onError:n})]});case"button":return o.jsxs("span",{className:"scrap-collage__button",style:{...e.styles,display:"inline-flex",alignItems:"center",justifyContent:"center",whiteSpace:"nowrap"},children:[e.innerSvg&&o.jsx("span",{className:"scrap-collage__button-icon","aria-hidden":"true",dangerouslySetInnerHTML:{__html:e.innerSvg}}),e.text]});case"svg-icon":return o.jsx("div",{className:"scrap-collage__svg","aria-hidden":"true",dangerouslySetInnerHTML:{__html:e.markup}});case"cursor":return o.jsxs(o.Fragment,{children:[o.jsx(Ge,{domain:e.domain,loaded:t,style:{inset:"auto",left:"50%",top:"50%",width:32,height:32,transform:"translate(-50%, -50%)"}}),o.jsx("img",{className:`scrap-collage__cursor scrap-collage__developing${t?" scrap-collage__developed":""}`,src:e.url,alt:"",loading:"lazy",draggable:!1,onLoad:r,onError:n})]})}}function la(){const[e,t]=s.useState(()=>typeof window>"u"||!window.matchMedia?!1:window.matchMedia("(prefers-reduced-motion: reduce)").matches);return s.useEffect(()=>{if(typeof window>"u"||!window.matchMedia)return;const n=window.matchMedia("(prefers-reduced-motion: reduce)"),r=()=>t(n.matches);return r(),n.addEventListener("change",r),()=>n.removeEventListener("change",r)},[]),e}function ca({items:e,seed:t,targetCount:n,perDomainCap:r,showKindFilter:l=!1}){const h=s.useRef(null),[p,u]=s.useState({width:0,height:0}),[c,x]=s.useState("all"),[y,A]=s.useState("drift"),[v,z]=s.useState("auto"),[O,M]=s.useState(0),[b,j]=s.useState(!0),[S,Y]=s.useState(0),[E,G]=s.useState(()=>new Set),[W,B]=s.useState(()=>new Set),[C,Q]=s.useState(()=>new Set),I=la(),[D,L]=s.useState(I),[H,ee]=s.useState(null),g=s.useRef(S),m=s.useRef(H);m.current=H;const[K,U]=s.useState([]),le=s.useRef(0),[F,te]=s.useState(null),X=s.useRef(null),V=s.useRef(null),ce=s.useRef(new Map),T=y==="archive",Z=t+S*10007,_e=n??(v==="auto"?Kt(p.width,p.height):v),ae=s.useMemo(()=>{const a={image:0,button:0,"svg-icon":0,cursor:0};for(const i of Ae(e))a[i.kind]+=1;return a},[e]),et=Object.values(ae).reduce((a,i)=>a+i,0),de=s.useMemo(()=>c==="all"?e:e.filter(a=>a.kind===c),[e,c]),q=s.useMemo(()=>Ae(de).sort((a,i)=>i.ts-a.ts||a.key.localeCompare(i.key)),[de]),Ne=s.useMemo(()=>Ie(q),[q]),oe=s.useMemo(()=>Gt(de,{seed:Z,targetCount:_e,perDomainCap:r}),[de,Z,r,_e]),J=s.useMemo(()=>{const a=new Map(q.map(d=>[d.key,d])),i=[];for(const d of oe)a.delete(d.key)&&i.push(d);return[...i,...a.values()]},[q,oe]),ne=Math.min(oe.length,J.length),re=!T&&J.length>ne,Re=s.useMemo(()=>new Map(J.map(a=>[a.key,a])),[J]);s.useEffect(()=>{ee(a=>{const i=g.current!==S;return g.current=S,qt(J.map(d=>d.key),ne,i?void 0:a??void 0)})},[S,ne,J]);const ze=s.useMemo(()=>H?H.ashore.map(a=>a===null?null:Re.get(a)??null):oe,[oe,Re,H]),be=s.useMemo(()=>T?oa(q,p.width,O,p.height,Z,Ne):{fieldHeight:0,layout:[]},[T,q,O,Ne,p,Z]),tt=T?be.fieldHeight:p.height,P=s.useMemo(()=>T?be.layout:na(ze,p.width,p.height,Z),[T,be.layout,p,Z,ze]),we=s.useRef(P);we.current=P;const ye=s.useRef(null);s.useEffect(()=>{c!=="all"&&ae[c]===0&&x("all")},[ae,c]),s.useEffect(()=>{T||M(0)},[T]),s.useEffect(()=>{if(!re||D)return;let a=!1;const i=new Set,d=(w,f)=>{const $=window.setTimeout(()=>{i.delete($),a||f()},w);i.add($)},_=()=>{const w=m.current;if(!w)return;const f=Qt(w);if(f.length===0)return;const $=f[Math.floor(Math.random()*f.length)],$e=I?void 0:we.current.find(ke=>ke.slotIndex===$);if(ee(Zt(w,$)),!$e)return;le.current+=1;const rt=le.current;U(ke=>[...ke,{layout:$e,washOutId:rt,startedAt:Date.now()}])},k=()=>{const w=m.current;if(!w)return;const f=Vt(w,ne,Math.random);if(f.kind==="in")ee(Jt(w));else{_();for(let $=1;$<f.count;$+=1)d($*f.staggerMs,_)}d(f.delayMs,k)};return d(Math.round(Te+Math.random()*(qe-Te)),k),()=>{a=!0;for(const w of i)window.clearTimeout(w)}},[I,re,ne,D]),s.useEffect(()=>{if(K.length===0)return;const a=Date.now(),i=K.filter(k=>a-k.startedAt>=ue);if(i.length>0){const k=new Set(i.map(w=>w.washOutId));U(w=>w.filter(f=>!k.has(f.washOutId)));return}const d=Math.min(...K.map(k=>k.startedAt+ue-a)),_=window.setTimeout(()=>{const k=Date.now();U(w=>w.filter(f=>k-f.startedAt<ue))},Math.max(d,0));return()=>window.clearTimeout(_)},[K]),s.useEffect(()=>{if(!re)return;const a=i=>{if(i.code!=="Space"||i.metaKey||i.ctrlKey||i.altKey)return;const d=document.activeElement;d instanceof HTMLElement&&(d.isContentEditable||["INPUT","TEXTAREA","SELECT","BUTTON","A"].includes(d.tagName))||(i.preventDefault(),L(_=>!_))};return window.addEventListener("keydown",a),()=>window.removeEventListener("keydown",a)},[re]),s.useEffect(()=>{const a=h.current;if(!a)return;const i=()=>{const _=a.getBoundingClientRect();u({width:_.width,height:_.height})};i();const d=new ResizeObserver(i);return d.observe(a),()=>d.disconnect()},[]);const at=a=>{G(i=>{if(i.has(a))return i;const d=new Set(i);return d.add(a),d})},Oe=a=>{B(i=>{if(i.has(a))return i;const d=new Set(i);return d.add(a),d})},ot=a=>{Q(i=>{if(i.has(a))return i;const d=new Set(i);return d.add(a),d})},pe=P.map(a=>a.item).filter(a=>!E.has(a.key)&&Ye(a)),se=F?pe.findIndex(a=>a.key===F.key):-1,N=se>=0?pe[se]:null,nt=(a,i)=>{const d=i.getBoundingClientRect(),_=P.find(k=>k.item.key===a.key);V.current=i,X.current===null&&(X.current=D,L(!0)),te({key:a.key,origin:{left:d.left,top:d.top,width:d.width,height:d.height,rotation:_?.rotation??0}})},ve=()=>{te(null),X.current!==null&&(L(X.current),X.current=null);const a=V.current;a?.isConnected?a.focus():h.current?.querySelector("[data-scrap-key]")?.focus(),V.current=null},De=s.useRef(ve);De.current=ve,s.useEffect(()=>{F&&!N&&De.current()},[N,F]);const Le=a=>{const i=pe[se+a];if(!i)return;const d=P.find(k=>k.item.key===i.key),_=ce.current.get(i.key)?.getBoundingClientRect();te({key:i.key,origin:_?{left:_.left,top:_.top,width:_.width,height:_.height,rotation:d?.rotation??0}:{left:0,top:0,width:0,height:0,rotation:0}})},Ue=(a,i)=>{if(E.has(a.item.key)||!Ye(a.item))return null;const d=W.has(a.item.domain),_=a.item.faviconUrl||`https://www.google.com/s2/favicons?domain=${encodeURIComponent(a.item.domain)}&sz=32`,k={left:a.x,top:a.y,width:a.width,height:a.height,zIndex:a.zIndex,"--scrap-rotation":`${a.rotation}deg`},w=sa(a.item);return o.jsxs("a",{className:`scrap-collage__tile${i}`,href:a.item.pageUrl,"data-scrap-key":a.item.key,ref:f=>{i.includes("washing-out")||(f?ce.current.set(a.item.key,f):ce.current.delete(a.item.key))},"aria-label":`Examine ${w}`,"aria-haspopup":"dialog",style:k,onClick:f=>{f.metaKey||f.ctrlKey||f.shiftKey||f.altKey||(f.preventDefault(),nt(a.item,f.currentTarget))},children:[o.jsx(ia,{item:a.item,loaded:C.has(a.item.key),onLoad:()=>ot(a.item.key),onError:()=>at(a.item.key)}),o.jsxs("div",{className:"scrap-collage__provenance",style:{...a.cardAbove?{bottom:"calc(100% + 10px)"}:{top:"calc(100% + 10px)"},...a.cardRightAligned?{right:0}:{left:0}},children:[d?o.jsx("span",{className:"scrap-collage__favicon",style:{backgroundColor:Ce(a.item.domain)}}):o.jsx("img",{className:"scrap-collage__favicon",src:_,alt:"",onError:()=>Oe(a.item.domain)}),o.jsxs("span",{className:"scrap-collage__details",children:[o.jsx("span",{className:"scrap-collage__title",children:w}),o.jsxs("span",{className:"scrap-collage__metadata",children:[a.item.kind," \xB7 ",a.item.domain,o.jsx("br",{}),"collected ",ea(a.item.ts)]})]})]})]},a.item.key)},Be=new Set;if(!T&&!I&&ye.current)for(const a of P)ye.current.has(a.item.key)||Be.add(a.item.key);ye.current=new Set(P.map(a=>a.item.key));const Fe=P.map(a=>Ue(a,Be.has(a.item.key)?" scrap-collage__tile--washing-in":""));return o.jsxs("div",{ref:h,style:{position:"relative",width:"100%",height:"100%"},children:[o.jsx("style",{children:ra}),l&&o.jsx("div",{className:`scrap-collage__controls${b?"":" scrap-collage__controls--collapsed"}`,"aria-label":"Scrap controls",children:b?o.jsxs(o.Fragment,{children:[o.jsxs("div",{className:"scrap-collage__controls-header",children:[o.jsxs("div",{className:"scrap-collage__view-switch",role:"group","aria-label":"Scrap view",children:[o.jsx("button",{type:"button",className:"scrap-collage__view-option","aria-pressed":!T,onClick:()=>A("drift"),children:"drift"}),o.jsx("button",{type:"button",className:"scrap-collage__view-option","aria-pressed":T,onClick:()=>A("archive"),children:"archive"})]}),o.jsx("button",{type:"button",className:"scrap-collage__filter scrap-collage__filter--collapse","aria-label":"Collapse scrap controls",title:"Collapse controls",onClick:()=>j(!1),children:"\u2193"})]}),o.jsxs("div",{className:"scrap-collage__controls-body",children:[o.jsxs("label",{className:"scrap-collage__control-group",children:[o.jsx("span",{className:"scrap-collage__control-label",children:"show"}),o.jsxs("select",{className:"scrap-collage__select","aria-label":"Kinds of scraps shown",value:c,onChange:a=>x(a.currentTarget.value),children:[o.jsxs("option",{value:"all",children:["all \xB7 ",et]}),Ht.map(({kind:a,label:i})=>ae[a]>0?o.jsxs("option",{value:a,children:[i," \xB7 ",ae[a]]},a):null)]})]}),T?o.jsxs("span",{className:"scrap-collage__archive-summary",children:["newest first \xB7 ",q.length]}):o.jsxs(o.Fragment,{children:[o.jsxs("label",{className:"scrap-collage__control-group",children:[o.jsx("span",{className:"scrap-collage__control-label",children:"amount"}),o.jsxs("select",{className:"scrap-collage__select","aria-label":"Number of scraps shown",value:v,onChange:a=>{const i=a.currentTarget.value;z(i==="auto"?i:Number(i))},children:[o.jsxs("option",{value:"auto",children:["fill screen \xB7 ",_e]}),o.jsx("option",{value:"100",children:"100"}),o.jsx("option",{value:"200",children:"200"}),o.jsx("option",{value:"300",children:"300"}),o.jsx("option",{value:"500",children:"500"})]})]}),o.jsx("button",{type:"button",className:"scrap-collage__filter",onClick:()=>Y(a=>a+1),children:"shuffle"}),re&&o.jsxs("button",{type:"button",className:"scrap-collage__filter scrap-collage__filter--cycle","aria-pressed":!D,title:"Turn automatic cycling on or off (spacebar)",onClick:()=>L(a=>!a),children:[o.jsx("span",{className:"scrap-collage__cycle-status","aria-hidden":"true"}),"cycle"]})]})]})]}):o.jsx("button",{type:"button",className:"scrap-collage__filter","aria-expanded":"false",onClick:()=>j(!0),children:"controls \u2191"})}),K.map(a=>o.jsx(st.Fragment,{children:Ue(a.layout," scrap-collage__tile--washing-out")},`washing-out-${a.washOutId}`)),T?o.jsx("div",{className:"scrap-collage__scroll",onScroll:a=>M(a.currentTarget.scrollTop),children:o.jsx("div",{className:"scrap-collage__field",style:{height:tt},children:Fe})}):Fe,F&&N&&dt.createPortal(o.jsx(yt,{item:N,origin:F.origin,faviconSrc:N.faviconUrl||`https://www.google.com/s2/favicons?domain=${encodeURIComponent(N.domain)}&sz=64`,faviconAvailable:!W.has(N.domain),onFaviconError:()=>Oe(N.domain),placeholderColor:Ce(N.domain),hasPrevious:se>0,hasNext:se<pe.length-1,prefersReducedMotion:I,currentOrigin:()=>{const a=ce.current.get(N.key);if(!a?.isConnected)return null;const i=a.getBoundingClientRect(),d=we.current.find(_=>_.item.key===N.key);return{left:i.left,top:i.top,width:i.width,height:i.height,rotation:d?.rotation??0}},onClose:ve,onPrevious:()=>Le(-1),onNext:()=>Le(1)},N.key),document.body)]})}function da(e){const t={id:e.id,key:e.key,pageTitle:e.pageTitle,...e.faviconUrl!==void 0?{faviconUrl:e.faviconUrl}:{},domain:e.domain,pageUrl:e.pageUrl,ts:e.ts};switch(e.kind){case"image":return{...t,kind:e.kind,src:e.src,...e.alt!==void 0?{alt:e.alt}:{},naturalWidth:e.naturalWidth,naturalHeight:e.naturalHeight};case"button":return{...t,kind:e.kind,text:e.text,styles:e.styles,...e.innerSvg!==void 0?{innerSvg:e.innerSvg}:{}};case"svg-icon":return{...t,kind:e.kind,markup:e.markup,width:e.width,height:e.height};case"cursor":return{...t,kind:e.kind,url:e.url,...e.hotspotX!==void 0?{hotspotX:e.hotspotX}:{},...e.hotspotY!==void 0?{hotspotY:e.hotspotY}:{}}}}const Me={position:"absolute",inset:0,zIndex:3,display:"flex",alignItems:"center",justifyContent:"center",padding:24,color:"#827a72",fontFamily:'"Martian Mono", monospace',fontSize:11,letterSpacing:"0.02em",textAlign:"center"};function pa(){const[e,t]=s.useState([]),[n,r]=s.useState(!0),[l,h]=s.useState(null),p=s.useMemo(()=>Math.floor(Date.now()/864e5),[]);return s.useEffect(()=>{(async()=>{try{const c=await lt.runtime.sendMessage({type:"GET_SCRAPS",options:{limit:5e3}});if(!c||!Array.isArray(c.scraps))throw new Error("GET_SCRAPS returned an invalid response");t(c.scraps.map(da))}catch(c){const x=c instanceof Error?c.message:String(c);h(x),console.error("Failed to load internet scraps:",c)}finally{r(!1)}})()},[]),o.jsxs("main",{style:{position:"relative",width:"100vw",height:"100vh",overflow:"hidden",background:"#faf9f6",color:"#3d3833"},children:[o.jsxs("svg",{width:"100%",height:"100%","aria-hidden":"true",style:{position:"absolute",inset:0,zIndex:1,opacity:.7,pointerEvents:"none",mixBlendMode:"multiply"},children:[o.jsxs("defs",{children:[o.jsxs("filter",{id:"scraps-paper-noise",children:[o.jsx("feTurbulence",{type:"fractalNoise",baseFrequency:"0.9",numOctaves:"3",stitchTiles:"stitch"}),o.jsx("feColorMatrix",{type:"matrix",values:"1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 2 -1"})]}),o.jsxs("filter",{id:"scraps-paper-grain",children:[o.jsx("feTurbulence",{type:"turbulence",baseFrequency:"0.5",numOctaves:"2",stitchTiles:"stitch"}),o.jsx("feColorMatrix",{type:"saturate",values:"0"}),o.jsx("feComponentTransfer",{children:o.jsx("feFuncA",{type:"discrete",tableValues:"0 0.2 0.3 0.4"})})]})]}),o.jsx("rect",{width:"100%",height:"100%",filter:"url(#scraps-paper-noise)"}),o.jsx("rect",{width:"100%",height:"100%",filter:"url(#scraps-paper-grain)",style:{opacity:.3}})]}),o.jsx("div",{style:{position:"absolute",top:14,left:20,right:20,zIndex:4,pointerEvents:"auto"},children:o.jsx(ct,{currentPage:"scraps"})}),o.jsxs("header",{style:{position:"absolute",top:14,left:"50%",zIndex:4,width:"min(520px, calc(100vw - 320px))",textAlign:"center",transform:"translateX(-50%)",pointerEvents:"none"},children:[o.jsx("h1",{style:{margin:0,color:"#3d3833",fontFamily:'"Martian Mono", monospace',fontSize:15,fontWeight:500,letterSpacing:"0.04em"},children:"internet scraps"}),o.jsx("p",{style:{margin:"5px 0 0",color:"#827a72",fontFamily:'"Martian Mono", monospace',fontSize:9,letterSpacing:"0.02em"},children:"images that washed up while you browsed"})]}),!n&&!l&&e.length>0&&o.jsx("div",{style:{position:"absolute",inset:"64px 0 0",zIndex:2},children:o.jsx(ca,{items:e,seed:p,showKindFilter:!0})}),n&&o.jsx("div",{style:Me,children:"gathering scraps..."}),!n&&l&&o.jsx("div",{style:Me,children:"scraps could not be gathered"}),!n&&!l&&e.length===0&&o.jsx("div",{style:Me,children:"nothing has washed up yet - browse a while"})]})}const Xe=document.getElementById("root");Xe&&it.createRoot(Xe).render(o.jsx(pa,{}));
