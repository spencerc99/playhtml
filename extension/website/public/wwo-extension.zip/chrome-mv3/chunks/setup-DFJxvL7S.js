import{r as n,j as e,d as G,b as w,W as ne,c as le}from"./browser-polyfill-DGrheA3Q.js";/* empty css                */import{u as ce,C as pe,s as de,h as ue,g as he}from"./color-DWgw3P0e.js";import{C as O,n as me,c as we,s as xe}from"./modes-CkS0UdaB.js";import{A as fe}from"./AnimatedTrails-DWJAhJAH.js";import{g as ge}from"./playerIdentity-DAimLkJq.js";import{L as ye}from"./keyboardRedaction-DJwCZJRj.js";import{i as be,N as _e}from"./takeover-C-egZnv0.js";import"./useFeatureAccess-DdfHzZ9p.js";import"./preload-helper-BXl3LOEh.js";const M=7e3,I=4,q=60;function je(t,r,o,a){const i=p=>{const m=Math.sin(a*9301+p*49297+233)*803.7;return m-Math.floor(m)},l=t*.15,c=r*.15,d=[];for(let p=0;p<o;p++)d.push({x:-l+i(p*2)*(t+l*2),y:-c+i(p*2+1)*(r+c*2)});return d}function ve(t,r){if(t.length<2)return t;const o=[],a=Math.floor(r/(t.length-1));for(let i=0;i<t.length-1;i++){const l=t[Math.max(0,i-1)],c=t[i],d=t[i+1],p=t[Math.min(t.length-1,i+2)];for(let m=0;m<a;m++){const u=m/a,f=.5*(2*c.x+(-l.x+d.x)*u+(2*l.x-5*c.x+4*d.x-p.x)*u*u+(-l.x+3*c.x-3*d.x+p.x)*u*u*u),g=.5*(2*c.y+(-l.y+d.y)*u+(2*l.y-5*c.y+4*d.y-p.y)*u*u+(-l.y+3*c.y-3*d.y+p.y)*u*u*u);o.push({x:f,y:g})}}return o.push(t[t.length-1]),o}function ke(t,r){const o=[];for(let a=0;a<q;a++){const i=a*M;for(let l=0;l<I;l++){const c=a*100+l,d=Math.sin(c*7919+1301)*1e4,p=G[Math.abs(Math.floor(d))%G.length],m=i+l/I*M*.4,u=M*(.5+.3*(c%7/7)),f=4+c%4,g=je(t,r,f,c),y=ve(g,120),v=y.map((b,_)=>({...b,ts:m+_/y.length*u}));o.push({trail:{id:`hero-${a}-${l}`,points:v,color:p,opacity:.65,startTime:m,endTime:m+u,clicks:[]},startOffsetMs:m,durationMs:u,variedPoints:y,clicksWithProgress:[]})}}return o}const B=q*M;function Ne({width:t,height:r}){const o=n.useMemo(()=>t>0&&r>0?ke(t,r):[],[t,r]);return o.length===0?null:e.jsx(fe,{trailStates:o,timeRange:{min:0,max:B,duration:B},showClickRipples:!1,windowSize:I,settings:{strokeWidth:5,trailOpacity:.2,animationSpeed:.5,clickMinRadius:6,clickMaxRadius:18,clickCoreRadius:3,clickMinDuration:300,clickMaxDuration:800,clickExpansionDuration:250,clickStrokeWidth:1.5,clickOpacity:.4,clickNumRings:2,clickRingDelayMs:120,clickAnimationStopPoint:.9}})}function Se(t){return new Date(t).toLocaleDateString("en-US",{month:"short",day:"numeric"}).toLowerCase()}const Ce="m12 24.4219v-16.015l11.591 11.619h-6.781l-.411.124z",Te="m21.0845 25.0962-3.605 1.535-4.682-11.089 3.686-1.553z";function A({cls:t}){return e.jsxs("svg",{className:`wwo-cursor-svg ${t}`,viewBox:"0 0 32 32",xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{d:Ce,fill:"#4a9a8a"}),e.jsx("path",{d:Te,fill:"#4a9a8a"})]})}function Ee({milestone:t}){if(t.type==="cursorDistance")return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"wwo-cursor-trail",children:[e.jsx(A,{cls:"wwo-c3"}),e.jsx(A,{cls:"wwo-c2"}),e.jsx(A,{cls:"wwo-c1"}),e.jsx(A,{cls:"wwo-c0"})]}),e.jsx("div",{className:"wwo-toast-stat",children:t.displayValue.replace(" mi","")}),e.jsx("div",{className:"wwo-toast-unit",children:"miles"})]});if(t.type==="screenTime"){const r=t.displayValue.split(" "),o=t.sparkline??Array(7).fill(.5);return e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"wwo-toast-stat wwo-toast-stat-sm",children:r.length===2?e.jsxs(e.Fragment,{children:[r[0],e.jsx("br",{}),r[1]]}):t.displayValue}),e.jsx("div",{className:"wwo-sparkline",children:o.map((a,i)=>{const l=Math.max(Math.round(a*100),5),c=i===6;return e.jsx("div",{className:`wwo-spark-bar${c?" wwo-current":""}`,style:{height:`${l}%`}},i)})})]})}if(t.type==="sitesExplored"){const r=[{top:1,left:5,size:3,opacity:.35},{top:6,left:22,size:4,opacity:.65},{top:14,left:8,size:3,opacity:.45},{top:2,left:33,size:5,opacity:.85},{top:18,left:30,size:3,opacity:.4},{top:9,left:16,size:3,opacity:.55}];return e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"wwo-toast-stat",children:t.displayValue}),e.jsx("div",{className:"wwo-toast-unit",children:"domains"}),e.jsx("div",{className:"wwo-scatter",children:r.map((o,a)=>e.jsx("div",{style:{position:"absolute",top:`${o.top}px`,left:`${o.left}px`,width:`${o.size}px`,height:`${o.size}px`,borderRadius:"50%",background:"#4a9a8a",opacity:o.opacity}},a))})]})}return e.jsx(Re,{milestone:t})}function Re({milestone:t}){const r=t.domain??"",o=r?`https://www.google.com/s2/favicons?domain=${encodeURIComponent(r)}&sz=64`:"",a=t.faviconUrl||o,[i,l]=n.useState(a?"primary":"letter"),c=(r||"?")[0].toUpperCase(),d=()=>{if(i==="primary"&&t.faviconUrl&&o){l("s2");return}l("letter")},p=i==="primary"?a:i==="s2"?o:"";return e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"wwo-favicon-wrap",children:i!=="letter"&&p?e.jsx("img",{className:"wwo-favicon-img",src:p,alt:"",onError:d}):e.jsx("span",{className:"wwo-favicon-fallback",children:c})}),e.jsx("div",{className:"wwo-toast-stat",style:{marginTop:5},children:t.displayValue}),t.type==="longGapReturn"&&e.jsx("div",{className:"wwo-toast-unit",children:"ago"})]})}function Ae({milestone:t,onCta:r,onDismiss:o,static:a,autoHideMs:i}){const[l,c]=n.useState(!!a),[d,p]=n.useState(!1),m=n.useRef(null);n.useEffect(()=>{if(a)return;let b=0;const _=requestAnimationFrame(()=>{b=requestAnimationFrame(()=>c(!0))});return()=>{cancelAnimationFrame(_),cancelAnimationFrame(b)}},[a]);const u=()=>{if(a){o?.();return}c(!1),p(!0),setTimeout(()=>o?.(),400)};n.useEffect(()=>{if(!i||a)return;const b=setTimeout(u,i);return()=>clearTimeout(b)},[i,a]);const f=()=>{r?.(t.ctaAction),u()},g=t.period==="today"?"wwo-today":"wwo-alltime",y=t.period==="today"?"today":"all time",v=["wwo-milestone-toast",l?"wwo-visible":"",d?"wwo-hiding":""].filter(Boolean).join(" ");return e.jsxs("div",{ref:m,className:v,children:[e.jsx("button",{type:"button",className:"wwo-toast-close",onClick:u,"aria-label":"Dismiss milestone",children:"\xD7"}),e.jsx("div",{className:"wwo-toast-wordmark",children:"wwo"}),e.jsxs("div",{className:"wwo-toast-body",children:[e.jsx("div",{className:"wwo-toast-accent",children:e.jsx(Ee,{milestone:t})}),e.jsxs("div",{className:"wwo-toast-text",children:[e.jsx("div",{className:`wwo-toast-badge ${g}`,children:y}),e.jsx("p",{className:"wwo-toast-headline",children:t.copy}),t.previousVisits&&t.previousVisits.length>0&&e.jsxs("p",{className:"wwo-toast-prev-visits",children:["before: ",t.previousVisits.map(Se).join(" \xB7 ")]}),e.jsx("button",{className:"wwo-toast-cta",onClick:f,children:t.ctaLabel})]})]})]})}const Le=`
.wwo-milestone-toast {
  background: #f5f0e8;
  border: 1px solid rgba(61, 56, 51, 0.12);
  border-radius: 10px;
  padding: 10px 13px 11px;
  width: 310px;
  box-shadow: 0 2px 12px rgba(61, 56, 51, 0.08);
  display: flex;
  flex-direction: column;
  gap: 0;
  position: relative;
  opacity: 0;
  transform: translateY(8px);
  transition: opacity 0.35s ease, transform 0.35s ease;
  pointer-events: none;
}

.wwo-milestone-toast.wwo-visible {
  opacity: 1;
  transform: translateY(0);
  pointer-events: auto;
}

.wwo-milestone-toast.wwo-hiding {
  opacity: 0;
  transform: translateY(4px);
}

.wwo-toast-close {
  position: absolute;
  top: 6px;
  right: 8px;
  z-index: 2;
  width: 22px;
  height: 22px;
  margin: 0;
  padding: 0;
  border: none;
  border-radius: 6px;
  background: transparent;
  color: rgba(61, 56, 51, 0.55);
  font-family: 'Atkinson Hyperlegible', -apple-system, sans-serif;
  font-size: 16px;
  line-height: 1;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.15s ease, background 0.15s ease, color 0.15s ease;
}

.wwo-milestone-toast:hover .wwo-toast-close,
.wwo-milestone-toast:focus-within .wwo-toast-close {
  opacity: 1;
}

.wwo-toast-close:hover {
  background: rgba(61, 56, 51, 0.08);
  color: rgba(61, 56, 51, 0.85);
}

.wwo-toast-close:focus-visible {
  opacity: 1;
  outline: 2px solid rgba(74, 154, 138, 0.55);
  outline-offset: 1px;
}

.wwo-toast-wordmark {
  position: absolute;
  top: 9px;
  right: 12px;
  font-family: 'Source Serif 4', 'Lora', Georgia, serif;
  font-style: italic;
  font-weight: 300;
  font-size: 12px;
  color: rgba(61, 56, 51, 0.55);
  letter-spacing: -0.01em;
  line-height: 1;
  user-select: none;
  transition: opacity 0.15s ease;
}

.wwo-milestone-toast:hover .wwo-toast-wordmark,
.wwo-milestone-toast:focus-within .wwo-toast-wordmark {
  opacity: 0;
}

.wwo-toast-body {
  display: flex;
  align-items: stretch;
  gap: 12px;
}

.wwo-toast-accent {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  flex-shrink: 0;
  width: 50px;
  border-right: 1px solid rgba(61, 56, 51, 0.08);
  padding-right: 12px;
  overflow: visible;
}

.wwo-toast-stat {
  font-family: 'Martian Mono', monospace;
  font-size: 18px;
  font-weight: 400;
  color: #4a9a8a;
  line-height: 1;
  text-align: center;
}

.wwo-toast-stat-sm {
  font-size: 15px;
  line-height: 1.2;
}

.wwo-toast-unit {
  font-family: 'Martian Mono', monospace;
  font-size: 7.5px;
  font-weight: 300;
  color: #4a9a8a;
  text-transform: uppercase;
  letter-spacing: 0.07em;
  text-align: center;
}

.wwo-toast-text {
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 4px;
  flex: 1;
  padding-right: 32px;
}

.wwo-toast-badge {
  font-family: 'Martian Mono', monospace;
  font-size: 7px;
  font-weight: 300;
  text-transform: uppercase;
  letter-spacing: 0.09em;
  color: #faf7f2;
  border-radius: 3px;
  padding: 1.5px 4px;
  line-height: 1.3;
  width: fit-content;
}

.wwo-toast-badge.wwo-today   { background: #4a9a8a; }
.wwo-toast-badge.wwo-alltime { background: #c4724e; }

.wwo-toast-headline {
  font-family: 'Lora', Georgia, serif;
  font-size: 12.5px;
  font-style: italic;
  font-weight: 600;
  color: #3d3833;
  line-height: 1.45;
  margin: 0;
}

.wwo-toast-prev-visits {
  font-family: 'Martian Mono', monospace;
  font-size: 8px;
  font-weight: 300;
  color: rgba(61, 56, 51, 0.5);
  letter-spacing: 0.02em;
  line-height: 1.3;
  margin: 0;
}

.wwo-toast-cta {
  font-family: 'Atkinson Hyperlegible', -apple-system, sans-serif;
  font-size: 10px;
  color: #4a9a8a;
  background: none;
  border: none;
  padding: 0;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 3px;
  width: fit-content;
  text-decoration: none;
}

.wwo-toast-cta::after {
  content: '\\2192';
  font-size: 10px;
}

/* Cursor trail animation */
.wwo-cursor-trail {
  position: relative;
  width: 44px;
  height: 24px;
  overflow: visible;
  margin-bottom: 2px;
}

.wwo-cursor-svg {
  position: absolute;
  width: 11px;
  height: 11px;
}

.wwo-cursor-svg.wwo-c0 {
  animation: wwo-drift 4.5s ease-in-out infinite;
  filter: drop-shadow(0 0 2px rgba(74, 154, 138, 0.45));
}
.wwo-cursor-svg.wwo-c1 { animation: wwo-drift 4.5s ease-in-out infinite; animation-delay: -0.25s; opacity: 0.42; }
.wwo-cursor-svg.wwo-c2 { animation: wwo-drift 4.5s ease-in-out infinite; animation-delay: -0.5s;  opacity: 0.20; }
.wwo-cursor-svg.wwo-c3 { animation: wwo-drift 4.5s ease-in-out infinite; animation-delay: -0.75s; opacity: 0.09; }

@keyframes wwo-drift {
  0%   { transform: translate(-2px, 12px); }
  25%  { transform: translate(12px, 3px);  }
  55%  { transform: translate(30px, 14px); }
  78%  { transform: translate(40px, 5px);  }
  100% { transform: translate(-2px, 12px); }
}

/* Sparkline */
.wwo-sparkline {
  width: 40px;
  height: 18px;
  display: flex;
  align-items: flex-end;
  gap: 2px;
  margin-top: 4px;
}

.wwo-spark-bar {
  flex: 1;
  border-radius: 1.5px 1.5px 0 0;
  background: rgba(74, 154, 138, 0.2);
  min-height: 2px;
}

.wwo-spark-bar.wwo-current { background: #4a9a8a; }

/* Scatter dots (sites explored) */
.wwo-scatter {
  position: relative;
  width: 40px;
  height: 22px;
  margin-top: 4px;
}

/* Favicon (domain visits) */
.wwo-favicon-wrap {
  width: 26px;
  height: 26px;
  border-radius: 5px;
  overflow: hidden;
  background: rgba(74, 154, 138, 0.1);
  border: 1px solid rgba(74, 154, 138, 0.2);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.wwo-favicon-img {
  width: 20px;
  height: 20px;
  object-fit: contain;
}

.wwo-favicon-fallback {
  font-family: 'Martian Mono', monospace;
  font-size: 13px;
  color: #4a9a8a;
  line-height: 1;
}
`,C={longGapReturn:["last time here","your last visit here","you were last here","the last time you visited"],cursorDistance:["your hand has been busy","your cursor's running around","good pixel coverage today!","lots of browsing today"],screenTime:["you've been present","this page held your attention","time passes differently online","hours spent, somewhere"],sitesExplored:["your curiosity runs wide","many links clicked","a well-traveled browser","you're a world (wide web) traveler"],domainVisits:["a place you keep returning to","familiar territory","a habit, maybe","this place knows you"]},H=[{type:"longGapReturn",displayValue:"15mo",copy:C.longGapReturn[0],ctaLabel:"see your history there",ctaAction:"TOGGLE_HISTORICAL_OVERLAY",period:"alltime",domain:"dearkellyfilm.com",faviconUrl:"https://www.google.com/s2/favicons?domain=dearkellyfilm.com&sz=64",previousVisits:[new Date("2025-04-04T12:00:00").getTime(),new Date("2025-03-18T12:00:00").getTime(),new Date("2025-03-11T12:00:00").getTime()]},{type:"cursorDistance",displayValue:"2.4 mi",copy:C.cursorDistance[0],ctaLabel:"see your trail",ctaAction:"TOGGLE_HISTORICAL_OVERLAY",period:"today"},{type:"screenTime",displayValue:"2h 14m",copy:C.screenTime[0],ctaLabel:"see your day",ctaAction:"TOGGLE_HISTORICAL_OVERLAY",period:"today",sparkline:[.2,.4,.55,.75,.5,.9,1]},{type:"sitesExplored",displayValue:"25",copy:C.sitesExplored[0],ctaLabel:"see your portrait",ctaAction:"OPEN_PORTRAIT",period:"alltime"},{type:"domainVisits",displayValue:"10\xD7",copy:C.domainVisits[0],ctaLabel:"see your history there",ctaAction:"TOGGLE_HISTORICAL_OVERLAY",period:"alltime",domain:"en.wikipedia.org",faviconUrl:"https://www.google.com/s2/favicons?domain=en.wikipedia.org&sz=64"}],F="wwo-milestone-toast-preview-styles";if(typeof document<"u"&&!document.getElementById(F)){const t=document.createElement("style");t.id=F,t.textContent=Le,document.head.appendChild(t)}const Me=3500;function Oe(){const[t,r]=n.useState(0),[o,a]=n.useState(0);return n.useEffect(()=>{const i=setInterval(()=>{r(l=>(l+1)%H.length)},Me);return()=>clearInterval(i)},[]),e.jsx("div",{className:"setup-step__milestone-preview",children:e.jsx(Ae,{milestone:H[t],static:!1,onDismiss:()=>a(i=>i+1)},`${t}-${o}`)})}const J=["http://*/*","https://*/*"];function Ie(){return w.permissions.contains({origins:J})}function Pe(){return w.permissions.request({origins:J})}const ze=[{id:"welcome",label:"welcome"},{id:"configure",label:"consent"},{id:"done",label:"complete"}],We="https://discord.gg/SKbsSf4ptU";function L(){const t=Math.floor(Math.random()*360);return ue(t,70,60)}function $(t){return t?"Safari couldn\u2019t save your choices. Disable and re-enable we were online in Safari Settings \u2192 Extensions, then try again.":"The extension couldn\u2019t save your choices. Check that it is enabled, then try again."}function De(){const t=he(),r=()=>{const a={};for(const i of t)a[i]="local";return a},o=()=>{const a={};for(const i of t)a[i]=xe(i)?"shared":"local";return a};return{abstain:{label:"Abstain",subhead:"Share nothing",description:"Nothing leaves this browser. Your portrait stays entirely local \u2014 a private record of your own wandering, including your full typing. You can change your mind anytime.",modes:r(),legibilityPct:100},participate:{label:"Participate",subhead:"Share how I move",description:"Your full browsing movement joins the collective portrait \u2014 cursor trails, scroll rhythm, pages visited, and typing cadence. Typed text is partially redacted by default; you can make it more or less legible below.",modes:o(),legibilityPct:50,recommended:!0},allIn:{label:"All-In",subhead:"Share everything",description:"Everything Participate shares, plus your typed text is fully legible (emails, phone numbers, and SSNs are still automatically redacted). You can tune legibility below.",modes:o(),legibilityPct:100}}}function Ve(){const[t,r]=n.useState("welcome"),o=new URLSearchParams(window.location.search).has("dev"),[a,i]=n.useState(""),l=ce(),[c,d]=n.useState(""),p=De(),[m,u]=n.useState("participate"),[f,g]=n.useState(p.participate.modes),[y,v]=n.useState(p.participate.legibilityPct),[b,_]=n.useState(!1),[P,X]=n.useState(!0),[z,T]=n.useState(!1),[k,E]=n.useState(null),[R,Z]=n.useState(null),W=n.useRef(null),D=n.useRef(null),[V,Q]=n.useState({width:0,height:0}),x=be(window.location.href),[N,S]=n.useState(x?"checking":"granted");n.useEffect(()=>{const s=D.current;if(!s)return;const h=()=>Q({width:s.clientWidth,height:s.clientHeight});h();const j=new ResizeObserver(h);return j.observe(s),()=>j.disconnect()},[]),n.useEffect(()=>{(async()=>{try{const s=await ge();if(s){const h=s.playerStyle.colorPalette[0];d(h&&typeof h=="string"?h:L())}else d(L())}catch{d(L())}})()},[]),n.useEffect(()=>{x&&Ie().then(s=>S(s?"granted":"needed")).catch(()=>S("error"))},[x]);const ee=async()=>{S("requesting");try{const s=await Pe();S(s?"granted":"needed")}catch{S("error")}},te=s=>{u(s),g(p[s].modes),v(p[s].legibilityPct),_(!1)},se=(s,h)=>{g(j=>({...j,[s]:h})),_(!0)},ae=s=>{v(Math.max(0,Math.min(100,Math.round(s)))),_(!0)},ie=async()=>{T(!0),E(null);try{const s={};for(const h of l)s[we(h)]=me(h,f[h]);s[ye]=y,await w.storage.local.set(s),await de(c),r("done")}catch{E($(x))}finally{T(!1)}},U=async()=>{const s=await w.tabs.getCurrent();if(s?.id===void 0)throw new Error("Could not find the setup tab");await w.tabs.remove(s.id)},oe=async()=>{T(!0),E(null);const s=a.trim();try{if(R){await U();return}let h=!1,j=!1;if(s)try{const Y=await fetch(`${ne}/subscribe`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:s,source:"extension-setup"})});if(!Y.ok)throw new Error(`Subscription failed with status ${Y.status}`);h=!0}catch{j=!0}if(await w.storage.local.set({onboarding_complete:"true",[_e]:x?!1:P,...h?{setup_email:s}:{}}),j){Z("Setup is complete, but we couldn\u2019t sign you up for updates. You can try again later from Settings.");return}await U()}catch{E($(x))}finally{T(!1)}},re=["abstain","participate","allIn"];return e.jsxs("div",{className:"setup-page",children:[e.jsx("div",{className:"setup-step__trail-art",ref:D,"aria-hidden":!0,children:e.jsx(Ne,{width:V.width,height:V.height})}),e.jsxs("div",{className:"setup-page__inner"+(t==="done"?" setup-page__inner--complete":""),children:[t==="welcome"&&e.jsxs("form",{className:"setup-step",onSubmit:s=>{s.preventDefault(),r("configure")},children:[e.jsx("h1",{className:"setup-step__title",children:"we were online"}),e.jsx("p",{className:"setup-step__desc",children:"we were online turns the existing Internet into a living, shared world. Let's get you set up in a few steps so we can respect your preferences for privacy and share how the extension works."}),e.jsxs("div",{className:"setup-step__discord-card",children:[e.jsxs("span",{className:"setup-step__discord-copy",children:[e.jsx("strong",{children:"Help shape WWO"}),e.jsx("span",{children:"Join the community to share what you're seeing and get a look at experiments before they ship."})]}),e.jsx("a",{href:We,target:"_blank",rel:"noreferrer",className:"setup-step__discord-button",children:"Join the Discord \u2197"})]}),x&&N!=="granted"&&e.jsxs("div",{className:"setup-step__website-access",children:[e.jsx("h2",{className:"setup-step__subheading",children:"Let it work across Safari"}),e.jsx("p",{className:"setup-step__desc",children:"Safari keeps the extension off on each new website until you allow access. This access lets it collect only the trail you choose to keep on the next screen."}),e.jsx("button",{type:"button",onClick:ee,className:"setup-step__btn-primary",disabled:N==="checking"||N==="requesting",children:N==="requesting"?"Waiting for Safari\u2026":"Allow on every website"}),e.jsx("p",{className:"setup-step__website-access-hint",children:"When Safari asks, choose \u201CAlways Allow on Every Website.\u201D"}),N==="error"&&e.jsx("p",{className:"setup-step__website-access-error",children:"Safari didn\u2019t change access. Try again, or open Safari Settings \u2192 Websites \u2192 Extensions."})]}),x&&N==="granted"&&e.jsx("p",{className:"setup-step__website-access-success",children:"Safari website access is on."}),e.jsxs("div",{className:"setup-step__field",children:[e.jsx("label",{className:"setup-step__field-label",htmlFor:"updates-email",children:"Email for project updates (optional)"}),e.jsx("input",{id:"updates-email",type:"email",value:a,onChange:s=>i(s.target.value),placeholder:"you@example.com",autoComplete:"email","aria-describedby":"updates-email-help",className:"setup-step__input"}),e.jsx("span",{id:"updates-email-help",className:"setup-step__field-help",children:"Get occasional updates about we were online and opportunities to help shape new features"})]}),e.jsxs("div",{className:"setup-step__welcome-actions",children:[e.jsx("button",{type:"submit",className:"setup-step__btn-primary",children:"Get started"}),e.jsx("span",{children:"takes about a minute"})]})]}),t==="configure"&&e.jsxs("section",{className:"setup-step",children:[e.jsx("h2",{className:"setup-step__heading",children:"Personalize your portrait"}),e.jsxs("div",{className:"setup-step__color-section",children:[e.jsx("label",{className:"setup-step__field-label",children:"Cursor color"}),e.jsxs("div",{className:"setup-step__color-picker-row",children:[e.jsx("input",{ref:W,type:"color",value:c,onChange:s=>d(s.target.value),className:"setup-step__color-input--hidden"}),e.jsx("button",{type:"button","aria-label":"Pick cursor color",title:"Click to pick a color",onClick:()=>W.current?.click(),className:"setup-step__cursor-preview",children:e.jsx(O,{size:36,color:c})}),e.jsx("button",{type:"button","aria-label":"Re-roll color",title:"Re-roll color",onClick:()=>d(L()),className:"setup-step__reroll-btn",children:"\u21BB"})]})]}),e.jsxs("h2",{className:"setup-step__heading",children:["Do you want to participate in"," ",e.jsx("a",{href:"https://spencer.place/creation/internet-movement",target:"_blank",rel:"noreferrer",className:"setup-step__heading-link",children:"Internet Movement"}),", a living, collective Internet portrait?"]}),e.jsx("p",{className:"setup-step__trust",children:"Your data is anonymously collected, stewarded by Spencer, and will never be sold or shared for any other purpose without your permission."}),e.jsx("div",{className:"setup-step__preset-tabs",children:re.map(s=>{const h=p[s];return e.jsxs("button",{className:"setup-step__preset-tab"+(m===s?" setup-step__preset-tab--active":""),onClick:()=>te(s),children:[e.jsx("span",{className:"setup-step__preset-label",children:h.label}),e.jsx("span",{className:"setup-step__preset-subhead",children:h.subhead}),h.recommended&&e.jsx("span",{className:"setup-step__preset-chip",children:"Recommended"})]},s)})}),e.jsxs("p",{className:"setup-step__preset-description",children:[p[m].description,b&&e.jsxs("span",{className:"setup-step__preset-customized",children:[" ","(customized)"]})]}),e.jsx(pe,{modes:f,onModeChange:se,keyboardLegibilityPct:y,onKeyboardLegibilityChange:ae}),e.jsxs("div",{className:"setup-step__actions",children:[e.jsx("button",{onClick:()=>r("welcome"),className:"setup-step__btn-secondary",children:"Back"}),e.jsx("button",{onClick:ie,className:"setup-step__btn-primary",disabled:z,children:k?"Try again":"Continue"})]}),k&&e.jsx("p",{className:"setup-step__save-error",role:"alert",children:k})]}),t==="done"&&e.jsxs("section",{className:"setup-step setup-step--complete",children:[e.jsx("h2",{className:"setup-step__heading",children:"All set!"}),e.jsx("p",{className:"setup-step__desc",children:"You can close this tab and open the popup to explore your portrait. A few things to know as you wander:"}),e.jsxs("div",{className:"setup-step__tips-grid",children:[e.jsxs("div",{className:"setup-step__tip",children:[e.jsx("h3",{className:"setup-step__subheading",children:"Review your browsing"}),e.jsxs("div",{className:"setup-step__newtab-preview",children:[e.jsxs("div",{className:"setup-step__newtab-chrome",children:[e.jsx("span",{className:"setup-step__newtab-dot setup-step__newtab-dot--close"}),e.jsx("span",{className:"setup-step__newtab-dot setup-step__newtab-dot--min"}),e.jsx("span",{className:"setup-step__newtab-dot setup-step__newtab-dot--expand"})]}),e.jsx("img",{src:w.runtime.getURL("setup/walking-record-preview.png"),alt:"Your history page: a week of browsing time, the sites you spent it on, and a portrait from each day.",className:"setup-step__newtab-shot"})]}),e.jsx("p",{className:"setup-step__desc",children:"Your history page reviews where your time went, the smaller places you explored, and a cursor portrait from each day."}),x?e.jsxs(e.Fragment,{children:[e.jsx("p",{className:"setup-step__newtab-note",children:"Safari doesn't let extensions change the new tab \u2014 bookmark or pin the history page to keep it a click away."}),e.jsx("a",{href:w.runtime.getURL("walking-record.html"),target:"_blank",rel:"noreferrer",className:"setup-step__text-link",children:"Open History \u2197"})]}):e.jsxs("label",{className:"setup-step__newtab-optin",children:[e.jsx("input",{type:"checkbox",checked:P,onChange:s=>X(s.target.checked)}),e.jsx("span",{children:"make this my new tab"})]})]}),e.jsxs("div",{className:"setup-step__tip setup-step__tip--trail",children:[e.jsx("h3",{className:"setup-step__subheading",children:"See your trail, anywhere"}),e.jsxs("div",{className:"setup-step__trail-preview","aria-hidden":"true",children:[e.jsxs("div",{className:"setup-step__trail-lines",children:[e.jsx("i",{}),e.jsx("i",{}),e.jsx("i",{}),e.jsx("i",{}),e.jsx("i",{}),e.jsx("i",{})]}),e.jsxs("svg",{viewBox:"0 0 420 140",fill:"none","aria-hidden":"true",children:[e.jsx("path",{d:"M38 111 C84 94 78 43 132 50 S188 118 236 87 S286 28 340 47",stroke:"#4a9a8a",strokeOpacity:"0.5",strokeWidth:"2",strokeLinecap:"round"}),e.jsx("path",{d:"M22 68 C70 18 118 106 167 78 S228 31 275 71 S328 119 394 83",stroke:"#c4724e",strokeOpacity:"0.4",strokeWidth:"2",strokeLinecap:"round"}),e.jsx("path",{d:"M 4 3 L 14 9 L 9.5 10.5 L 8 15 Z",fill:"#4a9a8a",transform:"translate(336 41)"})]})]}),e.jsxs("p",{className:"setup-step__desc",children:["Press"," ",e.jsx("kbd",{className:"setup-step__kbd",children:navigator.platform.includes("Mac")?"\u2318":"Ctrl"}),e.jsx("span",{className:"setup-step__kbd-plus",children:"+"}),e.jsx("kbd",{className:"setup-step__kbd",children:"Shift"}),e.jsx("span",{className:"setup-step__kbd-plus",children:"+"}),e.jsx("kbd",{className:"setup-step__kbd",children:"H"})," on any page to bring up your historical overlay\u2014the cursor trails, clicks, and scrolls you left there before."]})]}),e.jsxs("div",{className:"setup-step__tip",children:[e.jsx("h3",{className:"setup-step__subheading",children:"See your progress"}),e.jsx(Oe,{}),e.jsx("p",{className:"setup-step__desc",children:"We'll share some of your progress as you browse."}),e.jsxs("p",{className:"setup-step__progress-note",children:["Click"," ",e.jsx("span",{className:"setup-step__toolbar-icon",children:e.jsx("img",{src:w.runtime.getURL("icon/32.png"),alt:"we were online extension icon"})})," ","in your browser toolbar anytime to see your current portrait. Pin it to keep it one click away."]})]}),e.jsxs("div",{className:"setup-step__tip",children:[e.jsx("h3",{className:"setup-step__subheading",children:"Wikipedia feels inhabited"}),e.jsx("p",{className:"setup-step__desc",children:"On Wikipedia, live cursors, article chat, remembered links, and shared trails turn reading into a place where you can cross paths with other visitors."}),e.jsxs("div",{className:"setup-step__wiki-preview","aria-label":"Preview of live cursors on Wikipedia",children:[e.jsxs("div",{className:"setup-step__wiki-address",children:[e.jsx("strong",{children:"W"}),e.jsx("span",{children:"en.wikipedia.org/wiki/Rabbit_hole"})]}),e.jsxs("div",{className:"setup-step__wiki-article",children:[e.jsx("strong",{children:"Rabbit hole"}),e.jsx("i",{}),e.jsx("i",{}),e.jsx("i",{className:"setup-step__wiki-link"}),e.jsxs("span",{className:"setup-step__wiki-cursor setup-step__wiki-cursor--one",children:[e.jsx(O,{size:14,color:"#4a9a8a"}),e.jsx("em",{children:"mira"})]}),e.jsxs("span",{className:"setup-step__wiki-cursor setup-step__wiki-cursor--two",children:[e.jsx(O,{size:14,color:"#d8835d"}),e.jsx("em",{children:"sol"})]})]})]}),e.jsx("button",{type:"button",onClick:()=>{w.tabs.create({url:"https://en.wikipedia.org/wiki/Wikipedia:Today%27s_featured_article"})},className:"setup-step__text-link",children:"Visit Wikipedia \u2197"})]})]}),e.jsxs("form",{onSubmit:s=>{s.preventDefault(),oe()},children:[e.jsxs("div",{className:"setup-step__actions",children:[e.jsx("button",{type:"button",onClick:()=>r("configure"),className:"setup-step__btn-secondary",children:"Back"}),e.jsx("button",{type:"submit",className:"setup-step__btn-primary",disabled:z,children:R?"Close setup":k?"Try again":"Finish setup"})]}),R&&e.jsx("p",{className:"setup-step__save-error",role:"status",children:R}),k&&e.jsx("p",{className:"setup-step__save-error",role:"alert",children:k})]})]})]}),o?e.jsxs("nav",{className:"setup-page__dev-nav","aria-label":"Setup step preview",children:[e.jsx("span",{children:"dev"}),ze.map(({id:s,label:h})=>e.jsx("button",{type:"button","aria-current":t===s?"step":void 0,onClick:()=>r(s),children:h},s))]}):null]})}const K=document.getElementById("root");K&&le.createRoot(K).render(e.jsx(Ve,{}));
