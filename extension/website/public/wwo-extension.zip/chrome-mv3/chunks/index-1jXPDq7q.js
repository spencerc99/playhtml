import{F as r}from"./browser-polyfill-DGrheA3Q.js";var a=r();export{a as r};
